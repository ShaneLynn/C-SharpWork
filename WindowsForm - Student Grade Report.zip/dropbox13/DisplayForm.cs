﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Example 8.1 pg 225-264
//Assignment Date: 02/23/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox13
{
    public partial class DisplayForm : Form
    {
        //Setup a list that will hold all student's information
        List<Student> allStudent = new List<Student>();
        
        public DisplayForm()
        {
            InitializeComponent();
        }

        private void DisplayForm_Load(object sender, EventArgs e)
        {
            //Setup the object and loop to read data from the external file
            using (StreamReader sr = new StreamReader("student.txt"))
            {
                string id;

                while ((id = sr.ReadLine()) != null)
                {
                    string name = sr.ReadLine();
                    int score = int.Parse(sr.ReadLine());

                    //Create the student object for each group of 3 lines
                    Student student = new Student(id, name, score);

                    //Add the student to the list
                    allStudent.Add(student);

                    //Add the student to the listbox display
                    allStudentListBox.Items.Add(student);
                }
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            //Setup the click event for the print button
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //Print a header on the report
            e.Graphics.DrawString("All Students Grade Report", new Font("Times New Roman", 24, FontStyle.Bold), Brushes.Black, 200, 100);

            //Print date and time for the report
            e.Graphics.DrawString(DateTime.Now.ToString(), new Font("Courier New", 10, FontStyle.Italic), Brushes.Black, 100, 170);

            //Print a separator line
            e.Graphics.DrawString("=========================", new Font("Times New Roman", 24, FontStyle.Bold), Brushes.Black, 100, 175);

            //Print each student using a loop and format on the page
            int x = 100, y = 200;
            foreach (Student student in allStudent)
            {
                e.Graphics.DrawString(student.ToString(), new Font("Arial", 10, FontStyle.Regular), Brushes.Black, x, y);
                y += 15;
            }
        }

        private void printPrevButton_Click(object sender, EventArgs e)
        {
            //Setup the print preview button
            printPreviewDialog1.ClientSize = new System.Drawing.Size(800, 600);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1;
            printPreviewDialog1.ShowDialog();
        }
    }
}
