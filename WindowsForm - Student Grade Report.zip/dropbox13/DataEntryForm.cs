﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Example 8.1 pg 225-264
//Assignment Date: 02/23/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox13
{
    public partial class DataEntryForm : Form
    {
        public DataEntryForm()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            //Create the object to write to an external file
            using (StreamWriter sw = File.AppendText("student.txt"))
            { 
                if(!((string.IsNullOrWhiteSpace(idTextBox.Text)) ||
                    (string.IsNullOrWhiteSpace(nameTextBox.Text)) ||
                    (string.IsNullOrWhiteSpace(scoreTextBox.Text))))
                {
                    //Save the textbox content to the external file
                    sw.WriteLine(idTextBox.Text);
                    sw.WriteLine(nameTextBox.Text);
                    sw.WriteLine(scoreTextBox.Text);
                    
                    //Clear the textboxes once finished saving
                    clearButton.PerformClick();
                }
                else
                {
                    MessageBox.Show("All fields must be filled.");
                }
            }
        }

        private void DataEntryForm_Load(object sender, EventArgs e)
        {

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all of the fields and focus on the first text box
            idTextBox.Clear();
            nameTextBox.Clear();
            scoreTextBox.Clear();
            idTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
