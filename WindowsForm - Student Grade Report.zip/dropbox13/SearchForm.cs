﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Example 8.1 pg 225-264
//Assignment Date: 02/23/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox13
{
    public partial class SearchForm : Form
    {
       //Create the list to hold all of the student's information
        List<Student> allStudent = new List<Student>();
        public SearchForm()
        {
            
            InitializeComponent();
        }


        private void SearchForm_Load(object sender, EventArgs e)
        {
            //Setup the object and loop to read data from the external file
            using (StreamReader sr = new StreamReader("student.txt"))
            {
                string id;
                while((id= sr.ReadLine())!= null)
                { 
                string name = sr.ReadLine();
                int score = int.Parse(sr.ReadLine());

                    //Create the student object for each group of 3 lines
                    Student student = new Student(id, name, score);

                    //Add the student to the list
                    allStudent.Add(student);
                }
            }
        }

        private void searchTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            //Activate the enter key for text entry and use search button actions.
            if (e.KeyCode == Keys.Enter)
            {
                searchButton.PerformClick();
                
                //Stop with the beeping sound
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            //Search the populated list and find the student by the id provided
            Student student = allStudent.Find(x => x.StudentId == searchTextBox.Text);
            
            //Use an if check to search for the student by the provided ID
            if (student != null)
            {
                idLabel.Text = student.StudentId;
                nameLabel.Text = student.StudentName;
                scoreLabel.Text = student.StudentScore.ToString();
                gradeLabel.Text = student.GetLetterGrade().ToString();
            }
            else
            {
                MessageBox.Show("No student found.");
                
                //Reset the fields to display an empty box
                idLabel.Text = string.Empty;
                nameLabel.Text = string.Empty;
                scoreLabel.Text = string.Empty;
                gradeLabel.Text = string.Empty;


            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            //Setup the click event for the print button
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            //Print a header on the report
            e.Graphics.DrawString("Single Student Grade Report", new Font("Bookman Old Style", 24, FontStyle.Bold), Brushes.Black, 200, 100);

            //Print date and time for the report
            e.Graphics.DrawString(DateTime.Now.ToString(), new Font("Arial", 10, FontStyle.Italic), Brushes.Black, 100, 170);

            //Print a separator line
            e.Graphics.DrawString("=========================", new Font("Times New Roman", 24, FontStyle.Bold), Brushes.Black, 100, 175);

            //Print out the single student's information
            e.Graphics.DrawString("Student ID: " + idLabel.Text, new Font("Times New Roman", 12, FontStyle.Regular), Brushes.Black, 100, 200);
            e.Graphics.DrawString("Student Name: " + nameLabel.Text, new Font("Times New Roman", 12, FontStyle.Regular), Brushes.Black, 100, 215);
            e.Graphics.DrawString("Final Score: " + scoreLabel.Text, new Font("Times New Roman", 12, FontStyle.Regular), Brushes.Black, 100, 230);
            e.Graphics.DrawString("Student Grade: " + gradeLabel.Text, new Font("Times New Roman", 12, FontStyle.Regular), Brushes.Black, 100, 245);
        }

        private void printPrevButton_Click(object sender, EventArgs e)
        {
            //Setup the print preview button
            printPreviewDialog1.ClientSize = new System.Drawing.Size(800, 600);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1;
            printPreviewDialog1.ShowDialog();
        }

        
    }
}
