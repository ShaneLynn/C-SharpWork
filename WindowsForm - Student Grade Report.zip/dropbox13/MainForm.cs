﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Example 8.1 pg 225-264
//Assignment Date: 02/23/2021

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox13
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            //Activate the add a student window
            DataEntryForm entryForm = new DataEntryForm();
            entryForm.ShowDialog();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Activate the display students window
            DisplayForm displayForm = new DisplayForm();
            displayForm.ShowDialog();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            //Activate the search student form window
            SearchForm searchForm = new SearchForm();
            searchForm.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
