﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Example 8.1 pg 225-264
//Assignment Date: 02/23/2021

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dropbox13
{
    class Student
    {
        //Setup private fields for the class to use
        private string studentId;
        private string studentName;
        private double studentScore;

        //Setup the properties to access/update the private fields
        public string StudentId
        {
            get { return studentId; }
            set { studentId = value; }
        }

        public string StudentName
        {
            get { return studentName; }
            set { studentName = value; }
        }

        public double StudentScore
        {
            get { return studentScore; }
            set { studentScore = value; }
        }

        //Create the default Constructor
        public Student(string studentId, string studentName, double studentScore)
        {
            this.studentId = studentId;
            this.studentName = studentName;
            this.studentScore = studentScore;
        }

        //Setup the method to calculate the letter grade
        public string GetLetterGrade()
        {
            string grade = "X";

            if (studentScore >= 97)
                grade = "A+";
            else if (studentScore >= 93)
                grade = "A";
            else if (studentScore >= 90)
                grade = "A-";
            else if (studentScore >= 86)
                grade = "B+";
            else if (studentScore >= 83)
                grade = "B";
            else if (studentScore >= 80)
                grade = "B-";
            else if (studentScore >= 76)
                grade = "C+";
            else if (studentScore >= 73)
                grade = "C";
            else if (studentScore >= 70)
                grade = "C-";
            else if (studentScore >= 65)
                grade = "D";
            else
                grade = "F";

            return grade;
        }

        //Setup an override for the ToString() method to display the custom results.
        public override string ToString()
        {
            string str;
            str = string.Format("ID: {0} | Name: {1} | Score: {2} | Grade: {3}", StudentId, StudentName, StudentScore, GetLetterGrade());
            return str;
        }

    }
}
