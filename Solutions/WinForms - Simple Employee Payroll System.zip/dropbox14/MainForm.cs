﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Challenge 8.1 pg 265-267
//Assignment Date: 02/26/2021

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox14
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        //Load the corresponding forms for each button
        private void addNewEmployeeButton_Click(object sender, EventArgs e)
        {
            AddNewEmployeeForm AddEmployee = new AddNewEmployeeForm();
            AddEmployee.ShowDialog();
        }

        private void addHoursWorkedButton_Click(object sender, EventArgs e)
        {
            AddHoursWorkedForm HoursWorked = new AddHoursWorkedForm();
            HoursWorked.ShowDialog();
        }

        private void displayAllButton_Click(object sender, EventArgs e)
        {
            DisplayAllEmployeesForm DisplayAll = new DisplayAllEmployeesForm();
            DisplayAll.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
