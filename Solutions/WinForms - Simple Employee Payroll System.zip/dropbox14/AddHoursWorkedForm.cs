﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Challenge 8.1 pg 265-267
//Assignment Date: 02/26/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox14
{
    public partial class AddHoursWorkedForm : Form
    {
        //Setup the list to hold the employee information
        List<Employee> allEmployees = new List<Employee>();

        public AddHoursWorkedForm()
        {
            InitializeComponent();
        }

        private void AddHoursWorkedForm_Load(object sender, EventArgs e)
        {
            //Load the employee file and add the data to the list
            if(File.Exists("Employee.txt"))
            {
                using (StreamReader sr = new StreamReader("Employee.txt"))
                {
                    string employeeID = "";
                    while ((employeeID = sr.ReadLine())!= null)
                    {
                        Employee emp = new Employee(employeeID, sr.ReadLine(), decimal.Parse(sr.ReadLine()));
                        sr.ReadLine();
                        allEmployees.Add(emp);
                    }
                    //Display first employee's information
                    if(allEmployees.Count > 0)
                    {
                        empIdLabel.Text = allEmployees[0].EmployeeId;
                        employeeNameLabel.Text = allEmployees[0].EmployeeName;
                    }
                    else
                    {
                        //Inform the user all employees are accounted for
                        MessageBox.Show("No additional employees found!");
                        Close();
                    }
                }
            }
            else
            {
                //Inform the user that the employee file is missing
                MessageBox.Show("Missing Employee.txt file");
                Close();
            }
        }

        int count = 1;
        private void nextButton_Click(object sender, EventArgs e)
        {
            //Add the hours worked to the array from the textbox
            allEmployees[count - 1].HoursWorked = decimal.Parse(hoursWorkedTextBox.Text);

            if (count < allEmployees.Count)
            {
                empIdLabel.Text = allEmployees[count].EmployeeId;
                employeeNameLabel.Text = allEmployees[count].EmployeeName;
                count++;

                //Call the clear button action to reset the text box and focus it.
                clearButton.PerformClick();
                
            }
            else
            {
                MessageBox.Show("End of Records");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear any data in the textbox and focus for reentry
            hoursWorkedTextBox.Clear();
            hoursWorkedTextBox.Focus();
        }

        private void closeSaveButton_Click(object sender, EventArgs e)
        {
            //Write the full employee information to the file and close the window
            using(StreamWriter sw = File.CreateText("Employee.txt"))
            {
                foreach(Employee emp in allEmployees)
                {
                    sw.WriteLine(emp.EmployeeId);
                    sw.WriteLine(emp.EmployeeName);
                    sw.WriteLine(emp.PayRate);
                    sw.WriteLine(emp.HoursWorked);
                }
            }
            Close();
        }

        private void hoursWorkedTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            //Activate the enter key for text entry and use next button actions.
            if (e.KeyCode == Keys.Enter)
            {
                nextButton.PerformClick();

                //Stop the beeping sound
                e.SuppressKeyPress = true;
                e.Handled = true;
            }
        }
    }
}
