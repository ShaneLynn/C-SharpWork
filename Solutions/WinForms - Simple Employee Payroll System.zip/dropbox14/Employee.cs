﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Challenge 8.1 pg 265-267
//Assignment Date: 02/26/2021

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dropbox14
{
    class Employee
    {
        //Setup the fields to hold the employee data
        private string employeeId;
        private string employeeName;
        private decimal payRate;
        private decimal hoursWorked;

        //Constructors
        public Employee(string employeeId, string employeeName, decimal payRate)
        {
            this.employeeId = employeeId;
            this.employeeName = employeeName;
            this.payRate = payRate;
        }
        public Employee(string employeeId, string employeeName, decimal payRate, decimal hoursWorked)
        {
            this.employeeId = employeeId;
            this.employeeName = employeeName;
            this.payRate = payRate;
            this.hoursWorked = hoursWorked;
        }

        //Properties to adjust internal variables
        public string EmployeeId
        {
            get { return employeeId; }
            set { employeeId = value; }
        }
        public string EmployeeName
        {
            get { return employeeName; }
            set { employeeName = value; }
        }
        public decimal PayRate
        {
            get { return payRate; }
            set { payRate = value; }
        }
        public decimal HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked = value; }
        }

        //Method to calculate the pay based on hours worked and pay rate
        public decimal PayAmount()
        {
            decimal amount = 0.0m;
            amount = PayRate * HoursWorked;
            return amount;
        }

        //ToString override to display employee data
        public override string ToString()
        {
            string str;
            str = string.Format("Employee Id: {0} | Employee Name: {1} | Pay Rate: {2:C} | Hours Worked: {3} | Pay Amount: {4:C}", EmployeeId, EmployeeName, PayRate, HoursWorked, PayAmount());
            return str;
        }

    }
}
