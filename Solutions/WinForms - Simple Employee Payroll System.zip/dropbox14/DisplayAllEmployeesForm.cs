﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Challenge 8.1 pg 265-267
//Assignment Date: 02/26/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox14
{
    public partial class DisplayAllEmployeesForm : Form
    {
        //Setup the list to hold and display employee data
        List<Employee> allEmployees = new List<Employee>();

        public DisplayAllEmployeesForm()
        {
            InitializeComponent();
        }

        private void DisplayAllEmployeesForm_Load(object sender, EventArgs e)
        {
            //Use the reader to examine the input file and store the data in the list and display it
            if (File.Exists("Employee.txt"))
            {
                using (StreamReader sr = new StreamReader("Employee.txt"))
                {
                    string employeeId = "";
                    while ((employeeId = sr.ReadLine()) != null)
                    {
                        Employee emp = new Employee(employeeId, sr.ReadLine(), decimal.Parse(sr.ReadLine()), decimal.Parse(sr.ReadLine()));
                        allEmployeeListBox.Items.Add(emp);
                        allEmployees.Add(emp);
                    }
                }
            }
            else
            {
                allEmployeeListBox.Items.Add("No employees yet!");
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //Print a header on the report
            e.Graphics.DrawString("Current Employees - Payroll Report", new Font("Bookman Old Style", 28, FontStyle.Bold), Brushes.Black, 50, 100);

            //Print date and time for the report
            e.Graphics.DrawString(DateTime.Now.ToString(), new Font("Courier New", 12, FontStyle.Italic), Brushes.Black, 50, 170);

            //Print a separator line
            e.Graphics.DrawString("=================================", new Font("Times New Roman", 28, FontStyle.Bold), Brushes.Black, 50, 175);

            //Print each employee using a loop and format on the page
            int x = 50, y = 225;
            foreach (Employee emp in allEmployees)
            {
                e.Graphics.DrawString(emp.ToString(), new Font("Arial", 10, FontStyle.Regular), Brushes.Black, x, y);
                y += 15;
            }
        }

        private void printPrevButton_Click(object sender, EventArgs e)
        {
            //Setup the print preview button
            printPreviewDialog1.ClientSize = new System.Drawing.Size(800, 600);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1;
            printPreviewDialog1.ShowDialog();
        }
    }
}
