﻿//Christopher S Lynn
//CISS 201
//Agile Software Development
//Programming Challenge 8.1 pg 265-267
//Assignment Date: 02/26/2021

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dropbox14
{
    public partial class AddNewEmployeeForm : Form
    {
        public AddNewEmployeeForm()
        {
            InitializeComponent();
        }

        private void AddNewEmployeeForm_Load(object sender, EventArgs e)
        {
            empIdTextBox.Focus();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all of the text boxes and focus data entry at the top
            empIdTextBox.Clear();
            empNameTextBox.Clear();
            payRateTextBox.Clear();
            empIdTextBox.Focus();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            //Write the current text box data to a file
            Employee emp = new Employee(empIdTextBox.Text, empNameTextBox.Text, decimal.Parse(payRateTextBox.Text));
            using (StreamWriter sw = File.AppendText("Employee.txt"))
            {
                sw.WriteLine(emp.EmployeeId);
                sw.WriteLine(emp.EmployeeName);
                sw.WriteLine(emp.PayRate);
                sw.WriteLine(0);

                //Call the clear functionality to setup for a new entry
                clearButton.PerformClick();
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        
    }
}
